import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { auth, db } from "../firebase";
import { doc, updateDoc, onSnapshot } from "firebase/firestore";

import { ZoneModal } from "../components/game/ZoneModal";
import { ActionMenu } from "../components/game/ActionMenu";
import { OpponentActionMenu } from "../components/game/OpponentActionMenu"; // ★追加
import { OpponentArea } from "../components/game/OpponentArea";
import { PlayerArea } from "../components/game/PlayerArea";
import { ChatSidebar } from "../components/game/ChatSidebar";

const generateId = () => Math.random().toString(36).substr(2, 9);

export default function GameTable() {
  const { roomId } = useParams();
  const navigate = useNavigate();
  const user = auth.currentUser;

  const [isHost, setIsHost] = useState(false);
  const [roomData, setRoomData] = useState(null);
  
  const [myHand, setMyHand] = useState([]);
  const [myBattleZone, setMyBattleZone] = useState([]);
  const [myManaZone, setMyManaZone] = useState([]);
  const [myShields, setMyShields] = useState([]);
  const [myGraveyard, setMyGraveyard] = useState([]);
  const [myDeck, setMyDeck] = useState([]);
  const [myTempZone, setMyTempZone] = useState([]);

  const [selectedCard, setSelectedCard] = useState(null); 
  const [stackTarget, setStackTarget] = useState(null);
  const [zoomedUrl, setZoomedUrl] = useState(null);
  const [viewMode, setViewMode] = useState(null);
  const [interactionMode, setInteractionMode] = useState(false); // boolean
  const [selectedOpponentCard, setSelectedOpponentCard] = useState(null); // { zone, index }

  // --- 同期処理 ---
  useEffect(() => {
    if (!user || !roomId) return;
    const unsubscribe = onSnapshot(doc(db, "rooms", roomId), (docSnap) => {
      if (!docSnap.exists()) { alert("部屋が解散されました"); navigate("/"); return; }
      const data = docSnap.data();
      setRoomData(data);
      const amIHost = (data.hostId === user.uid);
      setIsHost(amIHost);
      
      const myData = amIHost ? data.hostData : data.guestData;
      if (myData) {
        setMyDeck(myData.deck || []);
        setMyHand(myData.hand || []);
        setMyShields(myData.shields || []);
        setMyGraveyard(myData.graveyard || []);
        setMyTempZone(normalizeZone(myData.tempZone));
        setMyBattleZone(normalizeZone(myData.battleZone));
        setMyManaZone(normalizeZone(myData.manaZone));
      }
    });
    return () => unsubscribe();
  }, [roomId, user]);

  const normalizeZone = (zoneData) => {
    if (!zoneData) return [];
    return zoneData.map(item => {
      if (typeof item === "string") {
        return { url: item, isTapped: false, isFaceDown: false, stack: [], id: generateId() };
      }
      return { ...item, isFaceDown: item.isFaceDown || false, stack: item.stack || [] };
    });
  };

  const syncToDB = async (newData) => {
    const fieldName = isHost ? "hostData" : "guestData";
    const dataToSave = {
      hand: newData.hand !== undefined ? newData.hand : myHand,
      battleZone: newData.battleZone !== undefined ? newData.battleZone : myBattleZone,
      manaZone: newData.manaZone !== undefined ? newData.manaZone : myManaZone,
      graveyard: newData.graveyard !== undefined ? newData.graveyard : myGraveyard,
      shields: newData.shields !== undefined ? newData.shields : myShields,
      deck: newData.deck !== undefined ? newData.deck : myDeck,
      tempZone: newData.tempZone !== undefined ? newData.tempZone : myTempZone,
    };
    
    if (newData.hand) setMyHand(newData.hand);
    if (newData.battleZone) setMyBattleZone(newData.battleZone);
    if (newData.manaZone) setMyManaZone(newData.manaZone);
    if (newData.graveyard) setMyGraveyard(newData.graveyard);
    if (newData.shields) setMyShields(newData.shields);
    if (newData.deck) setMyDeck(newData.deck);
    if (newData.tempZone) setMyTempZone(newData.tempZone);

    await updateDoc(doc(db, "rooms", roomId), { [fieldName]: dataToSave });
  };

  // --- 相手への干渉 ---
  const handleOpponentInteract = (targetZone, index) => {
    setSelectedOpponentCard({ zone: targetZone, index });
  };

  const executeOpponentAction = async (actionType) => {
    if (!roomData || !selectedOpponentCard) return;
    const opponentRole = isHost ? "guestData" : "hostData";
    const opponentData = roomData[opponentRole];
    if (!opponentData) return;

    const { zone, index } = selectedOpponentCard;
    let newOppData = { ...opponentData };
    
    // ターゲットの取得
    let targetCard = null;
    let targetUrl = "";
    let targetStack = [];

    // 取り出し処理
    if (zone === "battle") {
      const list = [...(newOppData.battleZone || [])];
      targetCard = list[index];
      list.splice(index, 1);
      newOppData.battleZone = list;
    } else if (zone === "mana") {
      const list = [...(newOppData.manaZone || [])];
      targetCard = list[index];
      list.splice(index, 1);
      newOppData.manaZone = list;
    } else if (zone === "shield") {
      const list = [...(newOppData.shields || [])];
      targetCard = list[index];
      list.splice(index, 1);
      newOppData.shields = list;
    }

    if (!targetCard) return;

    // データ正規化
    targetUrl = typeof targetCard === 'object' ? targetCard.url : targetCard;
    targetStack = typeof targetCard === 'object' ? (targetCard.stack || []) : [];
    
    // 移動先へ追加 (スタックがある場合はバラして移動)
    const cardsToMove = [targetUrl, ...targetStack];

    if (actionType === "grave") {
      const dest = [...(newOppData.graveyard || [])];
      cardsToMove.forEach(c => dest.push(c));
      newOppData.graveyard = dest;
    } else if (actionType === "hand") {
      const dest = [...(newOppData.hand || [])];
      cardsToMove.forEach(c => dest.push(c));
      newOppData.hand = dest;
    } else if (actionType === "mana") {
      const dest = [...(newOppData.manaZone || [])];
      // マナにはオブジェクトとして追加
      cardsToMove.forEach(c => dest.push({ url: c, isTapped: false, isFaceDown: false, id: generateId() }));
      newOppData.manaZone = dest;
    } else if (actionType === "shield") {
      const dest = [...(newOppData.shields || [])];
      cardsToMove.forEach(c => dest.push(c));
      newOppData.shields = dest;
    }

    await updateDoc(doc(db, "rooms", roomId), { [opponentRole]: newOppData });
    setSelectedOpponentCard(null);
    setInteractionMode(false); // 完了したらモード解除
  };

  // --- ゲームロジック ---
  const setupGame = () => {
    if (myDeck.length === 0 && myHand.length === 0) { alert("デッキがありません"); return; }
    if (!window.confirm("ゲームを開始しますか？")) return;

    const allCards = [
      ...myDeck, ...myHand, ...myShields, ...myGraveyard, ...myTempZone.map(c => c.url),
      ...myBattleZone.map(c => c.url), ...myManaZone.map(c => c.url)
    ];
    if (allCards.length < 10) { alert("カード不足"); return; }

    const shuffled = allCards.sort(() => Math.random() - 0.5);
    const newShields = shuffled.slice(0, 5);
    const newHand = shuffled.slice(5, 10);
    const newDeck = shuffled.slice(10);

    syncToDB({ deck: newDeck, hand: newHand, shields: newShields, battleZone: [], manaZone: [], graveyard: [], tempZone: [] });
    setSelectedCard(null);
  };

  const handleDeckInteraction = () => {
    if (myDeck.length === 0) return;
    if (viewMode === "temp") {
      const cardUrl = myDeck[0];
      const newDeck = myDeck.slice(1);
      const newTempCard = { url: cardUrl, isTapped: false, isFaceDown: true, id: generateId() };
      const newTempZone = [...myTempZone, newTempCard];
      syncToDB({ deck: newDeck, tempZone: newTempZone });
    } else {
      const card = myDeck[0];
      const newDeck = myDeck.slice(1);
      const newHand = [...myHand, card];
      syncToDB({ deck: newDeck, hand: newHand });
    }
  };

  const shuffleDeck = () => {
    if (myDeck.length <= 1) return;
    const newDeck = [...myDeck].sort(() => Math.random() - 0.5);
    syncToDB({ deck: newDeck });
    alert("山札をシャッフルしました");
    setSelectedCard(null);
  };

  const performMove = (targetZoneName) => {
    if (!selectedCard) return;
    const { zone: fromZone, index: fromIndex } = selectedCard;
    if (fromZone === targetZoneName) return;

    let cardUrl = "";
    let cardObj = null;
    let newHand = [...myHand], newBattle = [...myBattleZone], newMana = [...myManaZone];
    let newGrave = [...myGraveyard], newShields = [...myShields], newDeck = [...myDeck], newTemp = [...myTempZone];

    if (fromZone === "hand") { cardUrl = newHand[fromIndex]; newHand.splice(fromIndex, 1); }
    else if (fromZone === "battle") { 
      cardObj = newBattle[fromIndex];
      cardUrl = cardObj.url;
      if (cardObj.stack && cardObj.stack.length > 0) {
        const nextCardUrl = cardObj.stack[0];
        const newStack = cardObj.stack.slice(1);
        newBattle[fromIndex] = { ...cardObj, url: nextCardUrl, stack: newStack, isTapped: false };
      } else {
        newBattle.splice(fromIndex, 1);
      }
    }
    else if (fromZone === "mana") { cardObj = newMana[fromIndex]; cardUrl = cardObj.url; newMana.splice(fromIndex, 1); }
    else if (fromZone === "shield") { cardUrl = newShields[fromIndex]; newShields.splice(fromIndex, 1); }
    else if (fromZone === "grave") { cardUrl = newGrave[fromIndex]; newGrave.splice(fromIndex, 1); }
    else if (fromZone === "deck") { cardUrl = newDeck[fromIndex]; newDeck.splice(fromIndex, 1); }
    else if (fromZone === "temp") { 
      cardObj = newTemp[fromIndex]; 
      cardUrl = cardObj.url; 
      newTemp.splice(fromIndex, 1); 
    }

    const isTemp = targetZoneName === "temp";
    const newObj = { url: cardUrl, isTapped: false, isFaceDown: isTemp, stack: [], id: generateId() };
    
    if (targetZoneName === "battle") newBattle.push(newObj);
    else if (targetZoneName === "mana") newMana.push(newObj);
    else if (targetZoneName === "hand") newHand.push(cardUrl);
    else if (targetZoneName === "grave") newGrave.push(cardUrl);
    else if (targetZoneName === "shield") newShields.push(cardUrl);
    else if (targetZoneName === "deckTop") newDeck.unshift(cardUrl);
    else if (targetZoneName === "deckBottom") newDeck.push(cardUrl);
    else if (targetZoneName === "temp") newTemp.push(newObj);

    syncToDB({ hand: newHand, battleZone: newBattle, manaZone: newMana, graveyard: newGrave, shields: newShields, deck: newDeck, tempZone: newTemp });
    
    setSelectedCard(null);
    if (targetZoneName !== "temp" && fromZone !== "temp" && viewMode !== "temp") setViewMode(null);
  };

  const performStack = (mode) => {
    if (!selectedCard || !stackTarget) return;
    const { index: fromIndex } = selectedCard;
    const { index: toIndex } = stackTarget;
    if (fromIndex === toIndex) return;
    let newBattle = [...myBattleZone];
    let sourceObj = newBattle[fromIndex];
    const sourceStack = [sourceObj.url, ...(sourceObj.stack || [])];
    newBattle = newBattle.filter((_, i) => i !== fromIndex);
    let adjustedToIndex = toIndex;
    if (fromIndex < toIndex) adjustedToIndex -= 1;
    let newTarget = { ...newBattle[adjustedToIndex] };
    if (mode === "evolve") {
      newTarget.url = sourceObj.url; 
      newTarget.stack = [newBattle[adjustedToIndex].url, ...(newBattle[adjustedToIndex].stack || []), ...(sourceObj.stack || [])];
      newTarget.isTapped = false;
    } else if (mode === "under") {
      newTarget.stack = [...(newTarget.stack || []), ...sourceStack];
    }
    newBattle[adjustedToIndex] = newTarget;
    syncToDB({ battleZone: newBattle });
    setSelectedCard(null);
    setStackTarget(null);
  };

  const toggleStatus = (type) => {
    if (!selectedCard) return;
    const { zone, index } = selectedCard;
    if (zone === "battle") {
      const newZone = [...myBattleZone];
      if (type === "tap") newZone[index].isTapped = !newZone[index].isTapped;
      if (type === "face") newZone[index].isFaceDown = !newZone[index].isFaceDown;
      syncToDB({ battleZone: newZone });
    } else if (zone === "mana") {
      const newZone = [...myManaZone];
      if (type === "tap") newZone[index].isTapped = !newZone[index].isTapped;
      if (type === "face") newZone[index].isFaceDown = !newZone[index].isFaceDown;
      syncToDB({ manaZone: newZone });
    } else if (zone === "temp") {
      const newZone = [...myTempZone];
      if (type === "face") newZone[index].isFaceDown = !newZone[index].isFaceDown;
      syncToDB({ tempZone: newZone });
    }
    setSelectedCard(null);
  };

  const toggleTempAll = () => {
    if (myTempZone.length === 0) return;
    const currentStatus = myTempZone[0].isFaceDown;
    const newZone = myTempZone.map(card => ({ ...card, isFaceDown: !currentStatus }));
    syncToDB({ tempZone: newZone });
  };

  const startTurn = () => {
    const newBattle = myBattleZone.map(c => ({ ...c, isTapped: false }));
    const newMana = myManaZone.map(c => ({ ...c, isTapped: false }));
    let newDeck = [...myDeck];
    let newHand = [...myHand];
    if (newDeck.length > 0) {
      newHand.push(newDeck[0]);
      newDeck = newDeck.slice(1);
    }
    syncToDB({ battleZone: newBattle, manaZone: newMana, deck: newDeck, hand: newHand });
    setSelectedCard(null);
  };

  const handleCardTap = (e, zone, index, cardData) => {
    e.stopPropagation();
    if (selectedCard && selectedCard.zone === zone && selectedCard.index === index) { setSelectedCard(null); return; }
    if (selectedCard && selectedCard.zone === "battle" && zone === "battle") { setStackTarget({ index, data: cardData }); return; }
    if (selectedCard && selectedCard.zone !== zone) { performMove(zone); return; }
    setSelectedCard({ zone, index, data: cardData });
  };

  const handleZoneTap = (zoneName) => {
    if (selectedCard && selectedCard.zone !== zoneName) performMove(zoneName);
  };

  const getOpponent = () => isHost ? roomData?.guestData : roomData?.hostData;
  const opponent = getOpponent();

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100vh", background: "#0a0a0a", color: "#e0e0e0", userSelect: "none", overflow: "hidden" }}>
      
      <ChatSidebar roomId={roomId} user={user} />

      {zoomedUrl && (
        <div onClick={() => setZoomedUrl(null)} style={{ position: "fixed", top: 0, left: 0, width: "100%", height: "100%", background: "rgba(0,0,0,0.9)", zIndex: 4000, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <img src={zoomedUrl} style={{ maxWidth: "90%", maxHeight: "90%", borderRadius: "10px" }} />
        </div>
      )}

      {viewMode === "deck" && <ZoneModal title="山札確認" cards={myDeck} zoneName="deck" selectedCard={selectedCard} onClose={() => setViewMode(null)} onCardTap={handleCardTap} />}
      {viewMode === "grave" && <ZoneModal title="墓地確認" cards={myGraveyard} zoneName="grave" selectedCard={selectedCard} onClose={() => setViewMode(null)} onCardTap={handleCardTap} />}
      {viewMode === "temp" && <ZoneModal title="一時ゾーン" cards={myTempZone} zoneName="temp" selectedCard={selectedCard} onClose={() => setViewMode(null)} onCardTap={handleCardTap} onToggleFace={toggleTempAll} />}

      <OpponentArea 
        opponent={opponent} normalizeZone={normalizeZone} onZoom={setZoomedUrl} 
        interactionMode={interactionMode} onOpponentInteract={handleOpponentInteract}
      />

      <PlayerArea 
        hand={myHand} battleZone={myBattleZone} manaZone={myManaZone} shields={myShields} graveyard={myGraveyard} deck={myDeck} tempZone={myTempZone}
        selectedCard={selectedCard} interactionMode={interactionMode}
        onZoneTap={handleZoneTap} onCardTap={handleCardTap} 
        onDraw={handleDeckInteraction} 
        onViewMode={setViewMode}
        onSetup={setupGame} onStartTurn={startTurn} onShuffle={shuffleDeck}
        onSetInteractionMode={setInteractionMode}
      />

      {/* 自分のカードメニュー */}
      {!stackTarget && !selectedOpponentCard && (
        <ActionMenu 
          selectedCard={selectedCard} 
          onZoom={(url) => setZoomedUrl(url)} 
          onMove={performMove} 
          onToggleStatus={toggleStatus} 
          onShuffle={shuffleDeck}
          onClose={() => setSelectedCard(null)} 
        />
      )}

      {/* 相手カードメニュー */}
      {selectedOpponentCard && (
        <OpponentActionMenu 
          target={selectedOpponentCard}
          onClose={() => { setSelectedOpponentCard(null); setInteractionMode(false); }}
          onAction={executeOpponentAction}
        />
      )}

      {/* 重ねるメニュー */}
      {stackTarget && (
        <div style={{ 
          position: "absolute", top: "52%", left: "50%", transform: "translate(-50%, -50%)", 
          zIndex: 600, background: "rgba(0,0,0,0.95)", padding: "10px 15px", borderRadius: "8px", border: "1px solid #007bff", textAlign: "center", whiteSpace: "nowrap"
        }}>
          <p style={{margin: "0 0 10px 0", fontSize:"0.9rem"}}>重ねる</p>
          <div style={{display:"flex", gap:"10px"}}>
            <button className="btn btn-primary" onClick={() => performStack("evolve")} style={{fontSize:"0.8rem", padding:"5px 10px"}}>上に重ねる</button>
            <button className="btn btn-outline" onClick={() => performStack("under")} style={{fontSize:"0.8rem", padding:"5px 10px", borderColor:"#555"}}>下に重ねる</button>
          </div>
          <button className="btn" onClick={() => setStackTarget(null)} style={{marginTop:"8px", width:"100%", background:"#333", padding:"4px", fontSize:"0.8rem"}}>キャンセル</button>
        </div>
      )}
    </div>
  );
}
