export default function BBS() {
  return (
    <div style={{ padding: "20px" }}>
      <h2>掲示板</h2>
      <p>対戦募集やチャットをここで行います。</p>
    </div>
  );
}
